const MORSE_CODE_DICT = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---',
    'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-',
    'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--', 'Z': '--..', '1': '.----', '2': '..---', '3': '...--',
    '4': '....-', '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.', '0': '-----', ', ': '--..--',
    '.': '.-.-.-', '?': '..--..', '/': '-..-.', '-': '-....-', '(': '-.--.', ')': '-.--.-', ' ': ' '
};

function textToMorse(text) {
    let morseCode = '';
    for (const char of text.toUpperCase()) {
        if (char in MORSE_CODE_DICT) {
            morseCode += MORSE_CODE_DICT[char] + ' ';
        } else {
            morseCode += ' ';
        }
    }
    return morseCode;
}

function morseToText(morseCode) {
    const morseArray = morseCode.split(' ');
    let text = '';
    for (const code of morseArray) {
        for (const [key, value] of Object.entries(MORSE_CODE_DICT)) {
            if (code === value) {
                text += key;
            }
        }
    }
    return text;
}

function convertToMorse() {
    const inputText = document.getElementById('textToMorseInput').value;
    const morseResult = textToMorse(inputText);
    document.getElementById('textToMorseOutput').innerText = `Text to Morse: ${morseResult}`;
}

function convertToText() {
    const inputText = document.getElementById('morseToTextInput').value;
    const textResult = morseToText(inputText);
    document.getElementById('morseToTextOutput').innerText = `Morse to Text: ${textResult}`;
}
